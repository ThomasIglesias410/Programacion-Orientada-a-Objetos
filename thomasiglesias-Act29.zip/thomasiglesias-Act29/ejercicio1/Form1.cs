﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio1
{
    /*Consigna: Disponer tres CheckBox con productos y precios fijos. Un Button
&quot;Calcular Total&quot; debe evaluar los controles seleccionados (Checked == true), sumar
sus costos y mostrar el monto final en un Label.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = 0;
            if(checkBox1.Checked==true)
            {
                a += int.Parse(label2.Text);
            }
            if(checkBox2.Checked==true)
            {
                a += int.Parse(label1.Text);
            }
            if(checkBox3.Checked==true)
            {
                a += int.Parse(label3.Text);
            }
            label5.Text = a.ToString();
        }
    }
}
