﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio2
{
    /*Consigna: Crear tres NumericUpDown restringidos entre 0 y 255 (Rojo, Verde,
Azul). Un Button cambiará la propiedad BackColor del Form aplicando
Color.FromArgb().*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal rojo = numericUpDown1.Value;
            decimal verde = numericUpDown2.Value;
            decimal azul = numericUpDown3.Value;

            BackColor = Color.FromArgb((int)rojo, (int)verde, (int)azul);
        }
    }
}
