﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = "opinion recibida: "+textBox1.Text;
            if(radioButton1.Checked == true)
            {
                label3.Text += " Recomendación: "+ radioButton1.Text;
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    label3.Text += " Recomendación: " + radioButton2.Text;
                }
            }
        }
    }
}
