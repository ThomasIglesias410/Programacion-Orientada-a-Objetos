﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //2. Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"
            int num1, num2, num3, num4, num5, num6, promedio;

            string linea;
            linea = Console.ReadLine();
            Console.Write("nota 1:");
            num1 = int.Parse(linea);
            Console.Write("nota 2:");
            num2 = int.Parse(linea);
            Console.Write("nota 3:");
            num3 = int.Parse(linea);
            Console.Write("nota 4:");
            num4 = int.Parse(linea);
            Console.Write("nota 5:");
            num5 = int.Parse(linea);
            Console.Write("nota 6:");
            num6 = int.Parse(linea);

            promedio = (num1 + num2 + num3 + num4 + num5 + num6) / 6;
       
            
            if (promedio >= 7)
            {

                Console.WriteLine("Promocionado");
              

            }
            
        }
    }
}
