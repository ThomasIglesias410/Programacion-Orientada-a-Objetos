﻿// 2. Suma de los dos primeros y producto del tercero y cuarto


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el primer número: ");
            int n1 = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el segundo número: ");
            int n2 = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el tercer número: ");
            int n3 = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el cuarto número: ");
            int n4 = int.Parse(Console.ReadLine());

            int suma = n1 + n2;
            int producto = n3 * n4;

            Console.WriteLine("Suma: " + suma);
            Console.WriteLine("Producto: " + producto);

        }
    }
}
