﻿//calcular el perimetro de un cuadrado


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el lado del cuadrado: ");
            int lado = int.Parse(Console.ReadLine());

           
            int perimetro = lado * 4;
            

            Console.WriteLine("perimetro: " + perimetro);
            
        }
    }
}
