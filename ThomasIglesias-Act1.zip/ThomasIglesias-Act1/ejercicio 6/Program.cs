﻿// 6. Cálculo de IMC


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el peso (kg): ");
            int peso = int.Parse(Console.ReadLine());

            Console.Write("Ingrese la altura (m): ");
            double altura = double.Parse(Console.ReadLine());

            double imc = peso / (altura * altura);

            Console.WriteLine("IMC: " + imc);

        }
    }
}
