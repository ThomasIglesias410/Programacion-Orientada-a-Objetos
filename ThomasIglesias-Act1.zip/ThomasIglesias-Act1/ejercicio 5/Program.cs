﻿// 5. Circunferencia y área de un círculo


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el radio: ");
            int radio = int.Parse(Console.ReadLine());

            float pi = 3.14f;

            float circunferencia = 2 * pi * radio;
            float area = pi * radio * radio;

            Console.WriteLine("Circunferencia: " + circunferencia);
            Console.WriteLine("Área: " + area);

        }
    }
}
