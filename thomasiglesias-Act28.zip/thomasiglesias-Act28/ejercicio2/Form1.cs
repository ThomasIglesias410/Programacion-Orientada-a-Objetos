﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio2
{
    /*Disponer un TextBox para el ingreso numérico y dos RadioButton:
&quot;Celsius a Fahrenheit&quot; y &quot;Fahrenheit a Celsius&quot;. Al presionar un Button, realizar la
fórmula correspondiente y mostrar el resultado en un Label.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox1.Text);
            int res;
            if(radioButton1.Checked == true)
            {
                res = (a * 9 / 5) + 32;
                label1.Text = res.ToString();
            }
            else
            {
                if(radioButton2.Checked == true)
                {
                    res = (a - 32) * 5 / 9;
                    label1.Text = res.ToString();
                }
            }
           
        }
    }
}
