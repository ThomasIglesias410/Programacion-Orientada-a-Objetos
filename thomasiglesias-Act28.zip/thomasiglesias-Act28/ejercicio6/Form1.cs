﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio6
{
    /*Cargar en un ComboBox tres opciones. Al cambiar la selección mediante
el evento SelectedIndexChanged, mostrar la imagen correspondiente dentro del
PictureBox.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                pictureBox1.ImageLocation = "https://fotos.perfil.com/2023/08/01/cropped/696/696/center/boca-campeon-del-mundo-1621889.jpg";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = "https://i0.wp.com/bocajuniors2016.wordpress.com/wp-content/uploads/2016/02/rev_archivo_rt_0003.jpg?w=463&h=655&ssl=1";
            }
            if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgMROBRiJgWaWhtdKhrvFiz48wxWVFJFU36TPWWBF4MEfihSEPxmHQoRw&s=10";
            }
        }
    }
}
