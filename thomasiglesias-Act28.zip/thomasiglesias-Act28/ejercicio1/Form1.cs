﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(textBox1.Text);
            int n2 = int.Parse(textBox2.Text);
            int n3 = int.Parse(textBox3.Text);
            int prom = (n1 + n2 + n3) / 3;
            label1.Text = prom.ToString();
            if (prom >= 6)
            {
                label1.ForeColor = Color.DarkGreen;
            }
            else
            {
                label1.ForeColor = Color.Red;
            }
        }
    }
}
