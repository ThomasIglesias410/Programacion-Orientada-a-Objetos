﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio1
{
    /*Crear un formulario con tres TextBox para ingresar notas y un Button
&quot;Calcular&quot;. Convertir los valores con int.Parse() o double.Parse() y mostrar en una
Label el promedio. Si la nota es mayor o igual a 6, cambiar el color del texto de la
etiqueta a verde; de lo contrario, a rojo.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(textBox1.Text);
            int n2 = int.Parse(textBox2.Text);
            int n3 = int.Parse(textBox3.Text);
            int prom = (n1 + n2 + n3) / 3;
            label1.Text = prom.ToString();
            if (prom >= 6)
            {
                label1.ForeColor = Color.DarkGreen;
            }
            else
            {
                label1.ForeColor = Color.Red;
            }
        }
    }
}
