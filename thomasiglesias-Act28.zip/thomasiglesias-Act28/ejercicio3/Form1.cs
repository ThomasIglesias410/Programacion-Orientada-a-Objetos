﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio3
{
    /*Armar una interfaz con un TextBox, un Button &quot;Agregar&quot;, un Button
&quot;Eliminar&quot; y un ListBox. Permitir añadir el texto tipeado a la lista y borrar el elemento
que el usuario seleccione.*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            listBox1.Items.Add(a);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string a = textBox1.Text;
            listBox1.Items.Remove(a);
        }
    }
}
