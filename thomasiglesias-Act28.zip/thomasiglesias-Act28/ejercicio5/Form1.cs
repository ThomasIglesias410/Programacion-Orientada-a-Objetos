﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio5
{
    /*Crear un mini-juego donde un Button cuente cuántos clics realiza el
usuario en 10 segundos. Al finalizar el tiempo mediante el Timer, deshabilitar el
botón (Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.*/
    public partial class Form1 : Form
    {
        private int a;
        private int t;
        public Form1()
        {
            InitializeComponent();
            a = 0;
            t = 10;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            a++;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = t.ToString();
            t--;
            if (t == -1)
            {
                timer1.Enabled = false;
                button1.Enabled = false;
                MessageBox.Show(a.ToString());
            }
        }
    }
}
